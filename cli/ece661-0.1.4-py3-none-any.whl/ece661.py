#!/usr/bin/env python3
"""ECE 661 compute from your laptop: SSH keys, fixed-length machines, the group home and bucket.

Install the package once and run `ece661 login` to save your course key.
Every machine you start or list is written to ~/.ssh/ece661_config, so
`ssh ece661-<id>` and VS Code Remote-SSH work without copying addresses.
"""

from __future__ import annotations

import argparse
import contextlib
import getpass
import json
import os
import pathlib
import re
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Any

DEFAULT_BROKER = "https://34-127-166-57.sslip.io/broker"
VERSION = "0.1.4"
CONFIRM_ABOVE_USD = 1.0  # ask before reserving at least this much; --yes skips the question


def build_request(args: argparse.Namespace) -> tuple[str, str, dict[str, Any] | None]:
    """(method, path, json body) for the parsed command; pure so it can be tested."""
    if args.cmd == "ssh-key":
        return "POST", "/v1/ssh-key", {"public_key": pathlib.Path(args.path).expanduser().read_text().strip()}
    if args.cmd == "workspace" and args.sub == "status":
        return "GET", "/v1/workspace", None
    if args.cmd in ("compute", "workspace"):
        if args.sub == "start":
            body: dict[str, Any] = {"shape": args.shape, "hours": args.hours, "purpose": args.purpose,
                                    "on_demand": bool(args.on_demand)}
            body["workspace_run"] = getattr(args, "run", "default")
            if args.zone:
                body["zone"] = args.zone
            return "POST", "/v1/sessions", body
        if args.sub == "list":
            return "GET", "/v1/sessions", None
        return "POST", f"/v1/sessions/{args.id}/stop", None
    if args.cmd == "home":
        return "POST", "/v1/home", {"action": args.action}
    if args.cmd == "bucket":
        return ("POST", "/v1/bucket/token", None) if args.token else ("GET", "/v1/bucket", None)
    raise SystemExit(2)


def quote_path(args: argparse.Namespace) -> str:
    """The quote for the same start: what it would reserve, and whether it would be admitted."""
    _, _, body = build_request(args)
    return "/v1/quote?" + urllib.parse.urlencode({k: str(v).lower() if isinstance(v, bool) else v for k, v in (body or {}).items()})


def call(base: str, key: str, method: str, path: str, body: dict[str, Any] | None) -> tuple[int, Any]:
    data = json.dumps(body).encode() if body is not None else None
    request = urllib.request.Request(base.rstrip("/") + path, data=data, method=method,
                                     headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(request, timeout=240) as response:
            return response.status, json.loads(response.read() or b"null")
    except urllib.error.HTTPError as error:
        try:
            return error.code, json.loads(error.read() or b"null")
        except ValueError:
            return error.code, {"detail": str(error)}
    except (urllib.error.URLError, TimeoutError, OSError):
        return 503, {"detail": "Could not reach the course broker. Check your connection and try again."}


def credential_path() -> pathlib.Path:
    root = os.environ.get("ECE661_CONFIG_DIR")
    if root:
        return pathlib.Path(root).expanduser() / "credentials.json"
    return pathlib.Path(os.environ.get("XDG_CONFIG_HOME", pathlib.Path.home() / ".config")) / "ece661" / "credentials.json"


def saved_key(base: str) -> str:
    override = os.environ.get("ECE661_API_KEY", "").strip()
    if override:
        return override
    try:
        data = json.loads(credential_path().read_text())
    except FileNotFoundError:
        return ""
    except (OSError, ValueError):
        raise ValueError("Could not read your saved login. Run ece661 login again.") from None
    if not isinstance(data, dict) or data.get("broker") != base.rstrip("/"):
        raise ValueError("Your saved login belongs to a different broker. Run ece661 login for this broker.")
    return str(data.get("key") or "").strip()


def login(base: str, key_file: str | None) -> int:
    try:
        if key_file:
            raw = pathlib.Path(key_file).expanduser().read_text().strip()
            data = json.loads(raw) if raw.startswith("{") else raw
            key = data.get("key", "") if isinstance(data, dict) else data
        else:
            key = getpass.getpass("Course key (hidden): ")
        if not isinstance(key, str) or not key.strip():
            raise ValueError("No key found. Paste your course key at the prompt.")
        key = key.strip()
        status, _ = call(base, key, "GET", "/v1/sessions", None)
        if status >= 400:
            print(f"Login was not accepted (HTTP {status}). Your existing saved login was not changed.", file=sys.stderr)
            return 1
        path = credential_path()
        path.parent.mkdir(parents=True, mode=0o700, exist_ok=True)
        fd, temporary = tempfile.mkstemp(prefix=".credentials-", dir=path.parent)
        try:
            with os.fdopen(fd, "w") as out:
                json.dump({"broker": base.rstrip("/"), "key": key}, out)
                out.flush()
                os.fsync(out.fileno())
            os.replace(temporary, path)
        finally:
            pathlib.Path(temporary).unlink(missing_ok=True)
        print("Logged in. Your key is saved privately on this computer.")
        print("Next: ece661 ssh-key add\n      ece661 workspace status")
        return 0
    except (OSError, ValueError, EOFError):
        print("Could not complete login. Check your key and your connection, then try again.", file=sys.stderr)
        return 1


def format_workspace(payload: dict[str, Any]) -> str:
    spent = payload.get("spent") or {}
    lines = [f"Total allowance: ${float(spent.get('total', 0)):.2f} used / ${payload['total_allowance_usd']:.0f}",
             f"Compute:         ${float(spent.get('compute', 0)):.2f} used / ${payload['compute_allowance_usd']:.0f}",
             f"Session limit:   {payload['max_chips']} TPU chip, up to {payload['max_session_hours']:g} hours", ""]
    active = [row for row in payload.get("sessions", []) if row.get("state") not in ("ended", "failed", "done", "deleted")]
    lines.append(format_sessions(active) if active else "No active sessions. Start one with: ece661 workspace start")
    failed = [row for row in payload.get("sessions", []) if row.get("state") == "failed"]
    if failed:
        lines.extend(["", "Recent failed requests:", format_sessions(failed)])
    return "\n".join(lines)


# ---- SSH config: one managed file, included from ~/.ssh/config
def ssh_dir() -> pathlib.Path:
    return pathlib.Path(os.environ.get("ECE661_SSH_DIR") or pathlib.Path.home() / ".ssh").expanduser().resolve()


@contextlib.contextmanager
def _locked(folder: pathlib.Path) -> Any:
    """One writer at a time for the managed files; two CLI runs at once must not lose each other's aliases."""
    try:
        import fcntl
    except ImportError:  # not POSIX: proceed unlocked
        yield
        return
    with open(folder / ".ece661_lock", "w") as handle:
        fcntl.flock(handle, fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(handle, fcntl.LOCK_UN)


def alias_for(row: dict[str, Any]) -> str:
    return "ece661-home" if row.get("purpose") == "home" else f"ece661-{str(row.get('id') or '')[:8]}"


def split_ssh(line: str | None) -> tuple[str, str] | None:
    match = re.match(r"ssh (\S+)@(\S+)$", line or "")
    return (match.group(1), match.group(2)) if match else None


def _blocks(text: str) -> dict[str, list[str]]:
    out: dict[str, list[str]] = {}
    current = None
    for line in text.splitlines():
        if line.startswith("Host "):
            current = line.split(None, 1)[1].strip()
            out[current] = [line]
        elif current is not None and line.strip():
            out[current].append(line)
    return out


def remember_host(alias: str, user: str, ip: str) -> bool:
    """Write a Host block so `ssh <alias>` and VS Code Remote-SSH work; False if the files cannot be written."""
    try:
        folder = ssh_dir()
        folder.mkdir(mode=0o700, parents=True, exist_ok=True)
        managed, known = folder / "ece661_config", folder / "ece661_known_hosts"
        with _locked(folder):
            blocks = _blocks(managed.read_text()) if managed.exists() else {}
            block = [f"Host {alias}", f"  HostName {ip}", f"  User {user}", "  StrictHostKeyChecking accept-new",
                     f'  UserKnownHostsFile "{known}"']
            same_machine = blocks.get(alias) == block
            blocks = {a: b for a, b in blocks.items() if a != alias and f"  HostName {ip}" not in b}
            blocks[alias] = block
            managed.write_text("# Written by the ece661 command. Machines are new each time, so entries come and go.\n\n"
                               + "\n\n".join("\n".join(b) for b in blocks.values()) + "\n")
            managed.chmod(0o600)
            main = folder / "config"
            include = f'Include "{managed}"'
            text = main.read_text() if main.exists() else ""
            if include not in text:
                main.write_text(f"{include}\n\n{text}")
                main.chmod(0o600)
            # The trusted host key is forgotten only when the address now belongs to a different machine
            # (a new alias, or an alias whose address changed). Listing an unchanged machine keeps it.
            if known.exists() and not same_machine:
                subprocess.run(["ssh-keygen", "-R", ip, "-f", str(known)], capture_output=True, check=False)
        return True
    except (OSError, subprocess.SubprocessError):
        return False


def remember(row: dict[str, Any]) -> str | None:
    """Register the row's machine and return its alias, or None when there is no address yet."""
    parts = split_ssh(row.get("ssh"))
    if parts is None:
        return None
    alias = alias_for(row)
    return alias if remember_host(alias, parts[0], parts[1]) else None


# ---- output
def money_line(q: dict[str, Any]) -> str:
    rate = q.get("rate_usd_per_hour")
    rate_text = f"${float(rate):.4g}/h" if rate is not None else "unknown rate"
    left, cap = q.get("group_left_after_usd"), q.get("group_cap_usd")
    tail = f" Your group has ${float(left):,.2f} left after this, of ${float(cap):,.0f}." if left is not None and cap else ""
    if q.get("personal_compute_cap_usd") is not None:
        tail = f" Your personal allowance is ${float(q['personal_compute_cap_usd']):,.0f} for compute within ${float(q['personal_total_cap_usd']):,.0f} total."
    model = str(q.get("provisioning") or "").lower().replace("_", "-")
    return (f"Reserves ${float(q.get('reserved_usd') or 0):,.2f}: {q.get('shape')} ({model}) at {rate_text} "
            f"for {float(q.get('hours') or 0):g} h.{tail}")


def describe_machine(row: dict[str, Any]) -> list[str]:
    """The lines after a start or a home action: how to connect, where the bucket is, the idle rule."""
    lines: list[str] = []
    alias = remember(row)
    parts = split_ssh(row.get("ssh"))
    if parts and alias:
        lines += [f"SSH:      ssh {alias}    (ssh {parts[0]}@{parts[1]})",
                  f"VS Code:  code --remote ssh-remote+{alias} /home/{parts[0]}"]
    elif parts:
        lines.append(f"SSH:      ssh {parts[0]}@{parts[1]}")
    if row.get("bucket"):
        if row.get("purpose") == "workspace":
            lines.append("Files:    ~/project persists. Completed saves go in ~/checkpoint-spool; recovery is in ~/restored-state.")
        else:
            lines.append(f"Bucket:   {row['bucket']} mounted at /mnt/group. Keep checkpoints there: the disk is deleted with the machine.")
    if row.get("idle_minutes"):
        what = "stopped" if row.get("purpose") == "home" else "deleted"
        if row.get("purpose") == "workspace":
            lines.append(f"Idle:     Cleanup after {row['idle_minutes']} idle minutes, once completed backups are confirmed. SSH alone does not keep it active.")
        else:
            lines.append(f"Idle:     {what} after {row['idle_minutes']} minutes with no SSH session, no accelerator work, and low load. "
                         "A running job counts as work. Otherwise: touch /tmp/ece661-busy")
    if row.get("stopped_usd_per_day") is not None and row.get("running_usd_per_hour") is not None:
        lines.append(f"Cost:     ${float(row['running_usd_per_hour']):.3f}/h running, "
                     f"${float(row['stopped_usd_per_day']):.2f}/day stopped for the {row.get('disk_gb')} GB disk.")
    return lines


def format_sessions(rows: list[dict[str, Any]]) -> str:
    if not rows:
        return "No sessions. Start one with: ece661 compute start --shape v6e-1 --hours 8"
    head = f"{'ID':17}{'NAME':26}{'SHAPE':18}{'STATE':9}{'HOURS':>7}{'EST $':>9}  DEADLINE / SSH"
    lines = [head]
    for r in rows:
        alias = remember(r) if r.get("ssh") else None
        tail = f"ssh {alias}" if alias else (r.get("ssh") or (r.get("deadline") or "")[:16])
        lines.append(f"{r.get('id',''):17}{(r.get('name') or '')[:25]:26}{(r.get('shape') or '')[:17]:18}"
                     f"{(r.get('state') or ''):9}{r.get('running_hours', 0):7.1f}{float(r.get('est_cost_usd') or 0):9.2f}  {tail}")
        if r.get("error"):
            lines.append(f"  Reason: {r['error']}")
    return "\n".join(lines)


def print_refusal(status: int, payload: Any) -> None:
    detail = payload.get("detail") if isinstance(payload, dict) else payload
    if isinstance(detail, dict) and "reasons" in detail:
        print("Not admitted:\n  " + "\n  ".join(detail["reasons"]), file=sys.stderr)
    else:
        print(f"Error {status}: {detail}", file=sys.stderr)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="ece661", description="ECE 661 compute")
    ap.add_argument("--version", action="version", version=f"ece661 {VERSION}")
    ap.add_argument("--json", action="store_true", help="print only the broker's answer, as JSON, for scripts (implies --yes)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    auth = sub.add_parser("login", help="Save your course key on this computer",
                          description="Save your course key on this computer. ece661 login asks for the key "
                                      "from your key email at a hidden prompt.")
    auth.add_argument("--key-file", help="Optional. Read the key from a file you saved it to, instead of the prompt.")
    sub.add_parser("logout", help="Remove your saved login from this computer")
    hw = sub.add_parser("hw4", help="Prepare and open the HW4 bonus notebook on your laptop CPU")
    hw.add_argument("--directory", default="~/ECE661/HW4", help="Notebook folder; existing edits are preserved")
    hw.add_argument("--status", action="store_true", help="Recover the latest submitted result without starting Jupyter")
    hw.add_argument("--prepare-only", action="store_true", help="Prepare the notebook without opening a server")
    hw.add_argument("--no-browser", action="store_true", help="Print the local Jupyter link without opening a browser")
    hw.add_argument("--snapshot", help=argparse.SUPPRESS)
    k = sub.add_parser("ssh-key"); k.add_argument("verb", choices=["add"]); k.add_argument("path", nargs="?", default="~/.ssh/id_ed25519.pub")
    c = sub.add_parser("compute"); cs = c.add_subparsers(dest="sub", required=True)
    st = cs.add_parser("start")
    st.add_argument("--shape", default="v6e-1"); st.add_argument("--hours", type=float, default=24)
    st.add_argument("--purpose", default="project"); st.add_argument("--zone", default=None)
    st.add_argument("--on-demand", action="store_true")
    st.add_argument("-y", "--yes", action="store_true", help="reserve without asking, whatever it costs")
    cs.add_parser("list"); sp = cs.add_parser("stop"); sp.add_argument("id")
    w = sub.add_parser("workspace", help="Personal one-chip sessions with checkpoint backup")
    ws = w.add_subparsers(dest="sub", required=True)
    stw = ws.add_parser("start")
    stw.add_argument("--hours", type=float, default=8)
    stw.add_argument("--zone", default=None)
    stw.add_argument("--run", default="default", help="Use a new run name for incompatible experiments")
    stw.add_argument("--on-demand", action="store_true")
    stw.add_argument("-y", "--yes", action="store_true")
    stw.set_defaults(shape="v6e-1", purpose="workspace")
    ws.add_parser("status")
    pause = ws.add_parser("pause")
    pause.add_argument("id")
    pause.add_argument("--timeout", type=float, default=600)
    h = sub.add_parser("home"); h.add_argument("action", choices=["create", "start", "stop", "status"])
    b = sub.add_parser("bucket"); b.add_argument("--token", action="store_true")
    args = ap.parse_args(argv)
    base = os.environ.get("ECE661_BROKER_URL", DEFAULT_BROKER).rstrip("/")
    if args.cmd == "login":
        return login(base, args.key_file)
    if args.cmd == "logout":
        credential_path().unlink(missing_ok=True)
        print("Saved login removed from this computer.")
        if os.environ.get("ECE661_API_KEY"):
            print("ECE661_API_KEY is still set in your shell. Unset it to stop using that key.")
        return 0
    try:
        key = saved_key(base)
    except ValueError as error:
        print(str(error), file=sys.stderr)
        return 2
    if not key:
        print("Run ece661 login first. It asks for the course key from your key email.", file=sys.stderr)
        return 2
    if args.cmd == "hw4":
        try:
            from ece661_hw4 import launch
        except ImportError:
            print("HW4 requires the installed ece661 package, version 0.1.2 or later.", file=sys.stderr)
            return 2
        return launch(args, key, credential_path())
    starting = args.cmd in ("compute", "workspace") and args.sub == "start"
    if starting and not args.yes and not args.json:
        status, quote = call(base, key, "GET", quote_path(args), None)
        if status >= 400:
            print_refusal(status, quote)
            return 1
        if not quote.get("ok", True):
            print("Not admitted:\n  " + "\n  ".join(quote.get("reasons") or ["refused"]), file=sys.stderr)
            return 1
        print(money_line(quote))
        if float(quote.get("reserved_usd") or 0) >= CONFIRM_ABOVE_USD:
            if not sys.stdin.isatty():
                print("Add --yes to reserve this without a prompt.", file=sys.stderr)
                return 1
            if input("Reserve it? [y/N] ").strip().lower() not in ("y", "yes"):
                print("Nothing reserved.")
                return 0
    try:
        method, path, body = build_request(args)
    except OSError:
        print("Could not read your SSH public key. Check its path, or create one with ssh-keygen -t ed25519.", file=sys.stderr)
        return 2
    status, payload = call(base, key, method, path, body)
    if status >= 400:
        print_refusal(status, payload)
        return 1
    if args.cmd == "workspace" and args.sub == "pause":
        end = time.monotonic() + args.timeout
        while status < 400 and payload.get("state") == "checkpointing":
            if time.monotonic() >= end:
                print("Pause is still waiting for the guest to save and finish active work. No forced deletion was requested.", file=sys.stderr)
                return 1
            time.sleep(3)
            status, payload = call(base, key, method, path, body)
        if status >= 400:
            print_refusal(status, payload)
            return 1
    if args.cmd == "workspace" and args.sub == "status":
        for row in payload.get("sessions", []):remember(row)
        print(json.dumps(payload, indent=2) if args.json else format_workspace(payload))
        return 0
    if args.json:
        for row in (payload if isinstance(payload, list) else [payload]):
            if isinstance(row, dict):
                remember(row)
        print(json.dumps(payload, indent=2))
        return 0
    if args.cmd == "compute" and args.sub == "list" and isinstance(payload, list):
        print(format_sessions(payload))
        return 0
    if isinstance(payload, dict) and (starting or args.cmd == "home"):
        if starting and args.yes and payload.get("reserved_usd") is not None:
            print(money_line(dict(payload, hours=body["hours"] if body else 0, rate_usd_per_hour=payload.get("est_rate_usd_per_hour"))))
        if payload.get("detail"):
            print(payload["detail"])
        for field in ("id", "name", "state", "status"):
            if payload.get(field):
                print(f"{field.capitalize() + ':':10}{payload[field]}")
        print("\n".join(describe_machine(payload)))
        return 0
    print(json.dumps(payload, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
