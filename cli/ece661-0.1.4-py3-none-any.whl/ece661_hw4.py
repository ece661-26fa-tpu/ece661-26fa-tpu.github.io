"""Isolated local notebook launcher. No TPU is allocated by this command."""
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import urllib.error
import urllib.parse
import urllib.request
import zipfile

DEFAULT_SERVICE = 'https://34-127-166-57.sslip.io/hw4-api'


def download(base, path, key, limit=2_000_000):
    address = urllib.parse.urlsplit(base)
    if address.scheme != 'https' or not address.hostname or address.username or address.password or address.query or address.fragment:
        raise ValueError('The homework service must use a valid HTTPS address.')
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *args, **kwargs):
            return None
    request = urllib.request.Request(base.rstrip('/') + path, headers={'Authorization': 'Bearer ' + key})
    try:
        with urllib.request.build_opener(NoRedirect).open(request, timeout=60) as response:
            content = response.read(limit + 1)
    except urllib.error.HTTPError as error:
        if error.code in (401, 403):
            raise ValueError('Your course login does not currently have HW4 access. Check your login or contact staff.') from None
        raise ValueError('The homework package is temporarily unavailable. Try again later.') from None
    except (OSError, TimeoutError):
        raise ValueError('Could not reach the homework service. Check your connection and try again.') from None
    if len(content) > limit:
        raise ValueError('The homework package exceeded its size limit.')
    return content


def unpack(content, expected, destination):
    if hashlib.sha256(content).hexdigest() != expected:
        raise ValueError('The homework package failed its integrity check.')
    destination = Path(destination)
    with zipfile.ZipFile(io.BytesIO(content)) as archive:
        members = archive.infolist()
        if sum(member.file_size for member in members) > 5_000_000:
            raise ValueError('The expanded homework package is too large.')
        for member in members:
            path = Path(member.filename)
            if path.is_absolute() or path.drive or ':' in member.filename or '..' in path.parts or '\\' in member.filename or member.is_dir():
                raise ValueError('Unsafe homework package path.')
            if (member.external_attr >> 16) & 0o170000 == 0o120000:
                raise ValueError('Symlinks are not permitted in the homework package.')
        destination.mkdir(parents=True, exist_ok=True)
        for member in members:
            path = destination / member.filename
            if path.is_symlink() or any(parent.is_symlink() for parent in path.parents):
                raise ValueError('A package path is a symbolic link. Choose a different homework directory.')
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(archive.read(member))


def run_logged(command, log, env):
    with log.open('a') as output:
        result = subprocess.run(command, env=env, stdout=output, stderr=subprocess.STDOUT)
    if result.returncode:
        raise ValueError('Setup did not finish. The diagnostic log is saved at ' + str(log))


def _executable(path):
    return path.is_file() and os.access(path, os.X_OK)


def installer_uv():
    # install.sh places the CLI tool at <root>/tools/ece661 and its private uv at <root>/installer/uv,
    # so the tool environment's prefix locates uv for default and custom ECE661_INSTALL_ROOT alike.
    root = Path(sys.prefix).resolve().parent.parent
    for name in ('uv', 'uv.exe'):
        if _executable(root / 'installer' / name):
            return root / 'installer' / name
    return None


def uv_binary(cache, env, log):
    override = os.environ.get('ECE661_UV')
    if override:
        if not _executable(Path(override)):
            raise ValueError('ECE661_UV does not point to an executable uv.')
        return override
    owned = installer_uv()
    if owned:
        return str(owned)
    existing = shutil.which('uv', path=env.get('PATH'))
    if existing:
        return existing
    target = cache / 'uv'
    candidates = [target / 'bin/uv', target / 'bin/uv.exe', target / 'uv/uv', target / 'uv/uv.exe']
    if not any(_executable(path) for path in candidates):
        import importlib.util
        if importlib.util.find_spec('pip') is None:
            raise ValueError('The course installer\'s uv was not found. Rerun the ECE 661 installer, then run ece661 hw4 again.')
        print('Preparing the isolated Python environment…', flush=True)
        run_logged([sys.executable, '-m', 'pip', 'install', '--disable-pip-version-check', '--no-deps',
                    '--target', str(target), 'uv==0.8.22'], log, env)
    found = next((path for path in candidates if _executable(path)), None)
    if found is None:
        raise ValueError('Setup could not prepare uv. The diagnostic log is saved at ' + str(log))
    return str(found)


def launch(args, key, credential_path):
    try:
        base = os.environ.get('ECE661_HW4_URL', DEFAULT_SERVICE).rstrip('/')
        info = json.loads(download(base, '/v1/notebook', key))
        digest = info['bundle_sha256']
        if not isinstance(digest, str) or len(digest) != 64 or any(c not in '0123456789abcdef' for c in digest):
            raise ValueError('Invalid homework package manifest.')
        workspace = Path(args.directory).expanduser().resolve()
        workspace.mkdir(parents=True, exist_ok=True)
        cache = workspace / '.ece661'
        cache.mkdir(mode=0o700, exist_ok=True)
        support = cache / 'support' / digest
        content = download(base, '/v1/notebook/assets/' + digest + '.zip', key)
        unpack(content, digest, support)
        notebook = workspace / 'HW4-Bonus.ipynb'
        if not notebook.exists():
            data = download(base, '/v1/notebook/file', key)
            if hashlib.sha256(data).hexdigest() != info['notebook_sha256']:
                raise ValueError('The notebook changed during download. Rerun ece661 hw4.')
            # Exclusive creation prevents a concurrent launch overwriting edits.
            try:
                with notebook.open('xb') as stream:
                    stream.write(data)
            except FileExistsError:
                pass
        else:
            print('Opening your existing HW4-Bonus.ipynb; your edits are preserved.', flush=True)
        env = dict(os.environ, ECE661_API_KEY=key, PYTHONPATH=str(support), USE_TF='0', USE_FLAX='0')
        env.pop('PYTHONHOME', None)
        log = cache / 'setup.log'
        uv = uv_binary(cache, env, log)
        venv = cache / 'venv'
        python = venv / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
        if not python.exists():
            if shutil.disk_usage(workspace).free < 6 * 1024**3:
                raise ValueError('HW4 needs about 6 GB of free disk space for its separate environment and model.')
            run_logged([uv, 'venv', '--python', '3.12', str(venv)], log, env)
        marker = cache / 'environment-version'
        version = 'cpu-notebook-v1-' + hashlib.sha256((support / 'requirements-student.txt').read_bytes()).hexdigest()
        if not marker.exists() or marker.read_text() != version:
            print('Installing notebook support once. Your other Python environments are unchanged.', flush=True)
            if sys.platform != 'darwin':
                run_logged([uv, 'pip', 'install', '--python', str(python), 'torch==2.9.0',
                            '--index-url', 'https://download.pytorch.org/whl/cpu'], log, env)
            else:
                run_logged([uv, 'pip', 'install', '--python', str(python), 'torch==2.9.0'], log, env)
            run_logged([uv, 'pip', 'install', '--python', str(python), '-r', str(support / 'requirements-student.txt')], log, env)
            marker.write_text(version)
        if args.status:
            code = ('import json;from pathlib import Path;from hw4_decision.submission_client import SubmissionClient;'
                    'cfg=json.loads(Path(' + repr(str(support / 'student.json')) + ').read_text());'
                    'work=Path(' + repr(str(workspace / 'work')) + ');work.mkdir(exist_ok=True);'
                    'SubmissionClient(cfg,work).status()')
            return subprocess.run([str(python), '-c', code], env=env, cwd=workspace).returncode
        prepare = [str(python), '-m', 'hw4_decision.environment', '--support', str(support), '--workspace', str(workspace)]
        if args.snapshot:
            prepare += ['--snapshot', args.snapshot]
        result = subprocess.run(prepare, env=env, cwd=workspace)
        if result.returncode:
            return result.returncode
        env['ECE661_HW4_CONFIG'] = str(cache / 'hw4.json')
        env['PATH'] = str(python.parent) + os.pathsep + env.get('PATH', '')
        for variable, folder in [('JUPYTER_CONFIG_DIR', 'jupyter-config'), ('JUPYTER_DATA_DIR', 'jupyter-data'),
                                 ('JUPYTER_RUNTIME_DIR', 'jupyter-runtime')]:
            location = cache / folder
            location.mkdir(mode=0o700, exist_ok=True)
            env[variable] = str(location)
        kernel = cache / 'jupyter-data/kernels/python3'
        kernel.mkdir(parents=True, exist_ok=True)
        (kernel / 'kernel.json').write_text(json.dumps({'argv': [str(python), '-m', 'ipykernel_launcher', '-f', '{connection_file}'],
                                                       'display_name': 'ECE 661 HW4', 'language': 'python'}) + '\n')
        if args.prepare_only:
            print('Ready: ' + str(notebook))
            return 0
        with socket.socket() as probe:
            probe.bind(('127.0.0.1', 0))
            port = probe.getsockname()[1]
        command = [str(python), '-m', 'jupyterlab', '--ServerApp.ip=127.0.0.1',
                   '--ServerApp.port=' + str(port), '--ServerApp.port_retries=0',
                   '--ServerApp.root_dir=' + str(workspace), '--ServerApp.default_url=/lab/tree/HW4-Bonus.ipynb']
        if args.no_browser:
            command.append('--no-browser')
        print('Opening HW4 in your browser. Keep this terminal open; Ctrl+C stops your local notebook.', flush=True)
        return subprocess.run(command, cwd=workspace, env=env).returncode
    except (ValueError, OSError, KeyError, StopIteration, zipfile.BadZipFile) as error:
        print(str(error)[:400], file=sys.stderr)
        return 1
